# Advanced Scripting for Cloud
<H1>Template Repository for Advanced Scripting</H1>
Students will use this repository for submitting assignments

<H3>Some helpful git commands:</H3>
<b><i>git status<br>
git branch<br>
git branch branch_name<br>
git add .<br>
git commit -m "A commit message that describes the reason for the commit or the changes being made"<br>
git push origin branch_name<br>
  git pull origin branch_name<br></b></i>
#Hunter Hanson hjhanson@madisoncollege.edu
